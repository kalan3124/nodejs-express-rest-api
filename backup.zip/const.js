module.exports = {
  USER: "root",
  PASSWORD: "3124",
  CLUSTER: "cluster0",
  DB: "socialdb",
};
